$(document).ready(function() {
 $('.js-slide-left,.js-slide-right,.js-slide-left---movetoslide0').addClass('js-slide-hover');

 $('.artist-names__block').mouseover(function() {
  $(this).addClass('artistname__hover');

 });
 $('.artist-names__block').mouseout(function() {
  $(this).removeClass('artistname__hover');
 });

 $('.Janel,.js-janeltab').mouseover(function() {
  $('.fullimage').attr("src", '../Images/pro_1.png');
  $('.js-janeltab').addClass('bordertopclass');
 });

 $('.TippiShorter,.js-tippitab').mouseover(function() {
  $('.fullimage').attr("src", '../Images/pro_2.png');
  $('.js-tippitab').addClass('bordertopclass');
 });

 $('.IanMichael,.js-michaeltab').mouseover(function() {
  $('.fullimage').attr("src", '../Images/pro_3.png');
  $('.js-michaeltab').addClass('bordertopclass');
 });


 $('.Allen,.js-allentab').mouseover(function() {
  $('.fullimage').attr("src", '../Images/pro_4.png');
  $('.js-allentab').addClass('bordertopclass');
 });

 $('.Ricardo,.js-ricardo').mouseover(function() {
  $('.fullimage').attr("src", '../Images/pro_5.png');
  $('.js-ricardo').addClass('bordertopclass');
  $('.js-ricardo').removeClass('lastborder');
 });

 $('.Janel,.TippiShorter,.IanMichael,.Allen,.Ricardo,.js-janeltab,.js-tippitab,.js-michaeltab,.js-allentab,.js-ricardo').mouseout(function() {
  $('.fullimage').attr("src", '../Images/pros.png');
  $('.artist-names__block').removeClass('bordertopclass');
  $('.js-ricardo').addClass('lastborder');
 });

 //To scale up the image on hover of the span element and vicevers --- janelslide0.html
 $('.smiles,.overlap__lipstick').mouseover(function() {
  $('.overlap__lipstick').addClass('smiles__hover');
  $('.smiles').addClass('smileshoverclass');
 });

 $('.twinklingeyes,.pallette').mouseover(function() {
  $('.pallette').addClass('smiles__hover');
  $('.twinklingeyes').addClass('smileshoverclass');
 });

 $('.softhands,.hand__relief').mouseover(function() {
  $('.hand__relief').addClass('smiles__hover');
  $('.softhands').addClass('smileshoverclass');
 });

 $('.smiles,.twinklingeyes,.softhands,.overlap__lipstick,.pallette,.hand__relief').mouseout(function() {
  $('.overlap__lipstick,.pallette,.hand__relief').removeClass('smiles__hover');
  $('.smiles,.twinklingeyes,.softhands	').removeClass('smileshoverclass');
 });

 $('.js-janeltab').click(function() {
  window.location = "janelslide0.html";
 });

 //To scale up the image on hover of the span element and vicevers --- janelslide1.html
 function ex(var1, var2) {
  $(var1).addClass('producthover');
  $(var2).addClass('pinkhighlight');
 }
 $('.js-soothing,.js-bathsofbeauty,.shampure,.beautifying').mouseover(function() {

  if ($(this).hasClass("js-soothing")) {
   $('.shampure').addClass('producthover');
   $('.js-soothing').addClass('pinkhighlight');
   ex(var1, var2)
  } else if ($(this).hasClass("js-bathsofbeauty")) {
   $('.beautifying').addClass('producthover');
   $('.js-bathsofbeauty').addClass('pinkhighlight');
  } else if ($(this).hasClass("shampure")) {
   $('.js-soothing').addClass('pinkhighlight');
  } else if ($(this).hasClass("beautifying")) {
   $('.js-bathsofbeauty').addClass('pinkhighlight');
  }

 });
 $('.soothing,.js-bathsofbeauty,.shampure,.beautifying').mouseout(function() {
  if ($(this).hasClass("js-soothing")) {
   $('.shampure').removeClass('producthover');
   $('.js-soothing').removeClass('pinkhighlight');
  } else if ($(this).hasClass("js-bathsofbeauty")) {
   $('.beautifying').removeClass('producthover');
   $('.js-bathsofbeauty').removeClass('pinkhighlight');
  } else if ($(this).hasClass("shampure")) {
   $('.js-soothing').removeClass('pinkhighlight');
  } else if ($(this).hasClass("beautifying")) {
   $('.js-bathsofbeauty').removeClass('pinkhighlight');
  }

 });

 $('.js-slide-left,.js-slide-right,.js-slide-left---movetoslide0').mouseover(function() {
  $(this).removeClass('js-slide-hover');
 });
 $('.js-slide-left,.js-slide-right,.js-slide-left---movetoslide0').mouseout(function() {
  $(this).addClass('js-slide-hover');
 });
 $('.js-slide-left').click(function() {
  window.location = "index.html";
 });
 $('.js-slide-right').click(function() {
  window.location = "janelslide1.html";
 });
 $('.js-slide-left---movetoslide0').click(function() {
  window.location = "janelslide0.html";
 });

});