a=7;
b=9;
c=6;
d=0;
f=5;
if (a>b && a>c && a>d && a>f)
{
    window.alert(a);
}
else if (b>a && b>c && b>d && b>f)
{
    window.alert(b);
}
else if (c>a && c>b && c>d && c>f)
{
    window.alert(c);
}
else if (d>a && d>c && d>b && d>f)
{
    window.alert(d);
}
else
{
    window.alert(f);
}
