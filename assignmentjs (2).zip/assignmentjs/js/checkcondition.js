function myfunction(str)
{
  if (str.length < 4)
  {
    return false;
  }
  String = str.substring(0, 4);
  if (String == 'Java') 
  {
    return true;
  }
   else 
   {
    return false;
  }
}

console.log(myfunction("JavaScript"));
console.log(myfunction("Java"));
console.log(myfunction("Python"));
