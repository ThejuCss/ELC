$(document).ready(function() {
    $('.Janel,.janel').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_1.png');
            $('.janel').addClass("active"); 
    });
    $('.TippiShorter,.tippishorter').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_2.png');
            $('.tippishorter').addClass("active");
    });
    $('.IanMichael,.ianmichael').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_3.png');
            $('.ianmichael').addClass("active");
    });
    $('.Allen,.allen').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_4.png');
            $('.allen').addClass("active");
    });
    $('.Ricardo,.ricardo').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_5.png');
            $('.ricardo').addClass("active");
    });
    $('.Janel,.TippiShorter,.IanMichael,.Allen,.Ricardo,.janel,.tippishorter,.ianmichael,.allen,.ricardo').mouseout(function() {
        $('.fullimage').attr("src", '../images/pros.png');
        $('.author__item').removeClass("active");
    });
	$('.tourmalines,.tourmaline').mouseover(function() {
      $('.tourmalines').addClass('make');
      $('.tourmaline').addClass('tourmalinehover');
    });
    $('.tourmalines,.tourmaline').mouseout(function () {
      $('.tourmalines').removeClass('make');
      $('.tourmaline').removeClass('tourmalinehover');
    });
    $(' .shave, .shavingcream').mouseover(function () {
      $(' .shave').addClass("make");
      $(' .shavingcream').addClass('shavehover');
    });
    $(' .shave, .shavingcream').mouseout(function () {
      $('.shave').removeClass("make");
      $(' .shavingcream').removeClass('shavehover');
    });
    $('.beauty, .product').mouseover(function () {
      $('.beauty').addClass("make");
      $('.product').addClass('producthover');
    });
    $('.beauty, .product').mouseout(function () {
      $('.beauty').removeClass("make");
      $('.product').removeClass('producthover');
  });
  $('.beauty, .candle').mouseover(function () {
      $('.beauty').addClass("make");
      $('.candle').addClass('candlehover');
    });
    $('.beauty, .candle').mouseout(function () {
      $('.beauty').removeClass("make");
      $('.candle').removeClass('candlehover');
  });
});
