$(document).ready(function() {
    $('.Janel').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_1.png');
            $('#janel').addClass("active"); 
    });
    $('.TippiShorter').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_2.png');
            $('#tippishorter').addClass("active");
    });
    $('.IanMichael').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_3.png');
            $('#ianmichael').addClass("active");
    });
    $('.Allen').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_4.png');
            $('#allen').addClass("active");
    });
    $('.Ricardo').mouseover(function() {
            $('.fullimage').attr("src", '../images/pro_5.png');
            $('#ricardo').addClass("active");
    });
    $('.Janel,.TippiShorter,.IanMichael,.Allen,.Ricardo').mouseout(function() {
        $('.fullimage').attr("src", '../images/pros.png');
        $('.author__item').removeClass("active");
    });
	$('.tourmalines,.tourmaline').mouseover(function() {
      $('.tourmalines').addClass('make');
      $('.tourmaline').addClass('tourmalinehover');
    });
    $('.tourmalines,.tourmaline').mouseout(function () {
      $('.tourmalines').removeClass('make');
      $('.tourmaline').removeClass('tourmalinehover');
    });
    $(' .shave, .shavingcream').mouseover(function () {
      $(' .shave').addClass("make");
      $(' .shavingcream').addClass('shavehover');
    });
    $(' .shave, .shavingcream').mouseout(function () {
      $('.shave').removeClass("make");
      $(' .shavingcream').removeClass('shavehover');
    });
    $('.beauty, .product').mouseover(function () {
      $('.beauty').addClass("make");
      $('.product').addClass('producthover');
    });
    $('.beauty, .product').mouseout(function () {
      $('.beauty').removeClass("make");
      $('.product').removeClass('producthover');
  });


});