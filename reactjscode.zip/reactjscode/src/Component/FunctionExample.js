import React,{Component} from 'react';
import ReactDOM from 'react-dom';

class FunctionExample extends Component
{
    constructor(props)
    {
    super (props);
    this.state={
                 num:0,bgcolor:""
                 
    }
    this.increase=this.increase.bind(this)
        }
    increase =() => {
    
        let cur=this.state.num;
        let new_val=cur+1;
        this.state.bgcolor=(new_val%2===0)? "green": "red" ;
        this.setState({bgcolor:this.state.bgcolor,num:new_val});
    }
    render()
    {
        let div_style={color:this.state.bgcolor}
        return(
            
            <div style={div_style}>
                value of num is{this.state.num}
                <button onClick={this.increase}>increase</button>
               
                </div>
        );
        
    }
}
export default FunctionExample;
