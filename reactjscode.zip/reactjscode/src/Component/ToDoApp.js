import React, { Component } from 'react';
class ToDoApp extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
        toDoList:["meeting","shopping"],
        toDoValue:""
     }
     this.handleChange=this.handleChange.bind(this);
     this.addToDo=this.addToDo.bind(this);
     this.delToDo=this.delToDo.bind(this);
    }
    handleChange(event)
    {
        let val =event.target.value;
        this.setState({toDoValue:val})
    }
    addToDo()
    {
        let val =this.state.toDoValue;
        let arr=this.state.toDoList;
        arr.push(val);
        console.log(arr);
        this.setState({toDoList:arr,toDoValue:""})
    }
    delToDo()
    {
       let val =this.state.toDoValue;
       let arr=this.state.toDoList;
        arr.pop(val);
        this.setState({toDoList:arr,toDoValue:""})
    }
    updateToDo()
    {
        let val =this.state.toDoValue;
        let arr=this.state.toDoList;
        arr.update(val);
        console.log(arr);
        this.setState({toDoList:arr,toDoValue:""})
          }
    }
    render()
    {
        return(
            <div>
                <h1>To Do App</h1>
                <input type="text" value={this.state.toDoValue} onChange={this.handleChange}/>
                <button onClick={this.addToDo}>Add</button>
                {
                this.state.toDoList.map((item,i)=>
                <li>{item}</li>)
                }
                <button onClick={this.delToDo}>X</button>
                {
                this.state.toDoList.map((item,i)=>
                <li>{item}</li>)
                }
            </div>
        )
    }
export default ToDoApp;