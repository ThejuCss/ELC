import React from 'react';
import ReactDOM from 'react-dom';
import ToDoApp from './Component/ToDoApp'
import FunctionExample from './Component/FunctionExample'
import Test from './Component/Test'
import * as serviceWorker from './serviceWorker';
//ReactDOM.render(<Test />, document.getElementById('root'));
//ReactDOM.render(<FunctionExample/>, document.getElementById('root'));
ReactDOM.render(<ToDoApp />, document.getElementById('root'));
serviceWorker.unregister();
