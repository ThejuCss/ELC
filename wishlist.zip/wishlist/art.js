
$(document).ready(function(){

$('#Janel').mouseover(function(){
var flag=0;
if(flag==0)
{
$('.fullimage').attr("src",'./pro_1.png');
$('#janel').css("border-top",'8px solid #C8122B');
}
});

$('#TippiShorter').mouseover(function(){
var flag=0;
if(flag==0)
{
$('.fullimage').attr("src",'./pro_2.png');
$('#tippishorter').css("border-top",'8px solid #C8122B');
}
});
$('#IanMichael').mouseover(function(){
var flag=0;
if(flag==0)
{
$('.fullimage').attr("src",'./pro_3.png');
$('#ianmichael').css("border-top",'8px solid #C8122B');
}
});
$('#Allen').mouseover(function(){
var flag=0;
if(flag==0)
{
$('.fullimage').attr("src",'./pro_4.png');
$('#allen').css("border-top",'8px solid #C8122B');
}
});
$('#Ricardo').mouseover(function(){
var flag=0;
if(flag==0)
{
$('.fullimage').attr("src",'./pro_5.png');
$('#ricardo').css("border-top",'8px solid #C8122B');
}
});
$('#Janel,#TippiShorter,#IanMichael,#Allen,#Ricardo').mouseout(function() {
$('.authoritem').css("border-top",'none');
$('.fullimage').attr("src",'./pros.png');
});

});


